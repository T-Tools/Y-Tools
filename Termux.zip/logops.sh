#Colors
RED='\033[0;31m'
BLACK='\033[0;30m'
DG='\033[1;31m'
LIGHT RED='\033[1;31m'
GR='\033[0;32m'
LIGHTGREEN='\033[1;32m'
ORANGE='\033[0;33m'
YELLOW='\033[1;33m'
BL='\033[0;34m'
LIGHT BLUE='\033[1;34m'
PURPLE='\033[0;35m'
LIGHT PURPLE='\033[1;35m'
CYAN='\033[0;36m'
LIGHT CYAN='\033[0;36m'
GRAY='\033[0;37m'
LIGHT GRAY='\033[0;37m'
RED='\033[0;31m'
YO='\033[0;33m'
BLU='\033[0;34m'
#
clear


echo  ${GR}"

                               █▀▄ █░░ ▄▀▄ █▄░█ █▀▀ ▄▀▀ █▀▄ █░░ ▄▀▄ ▀ ▀█▀
                               █░█ █▀▄ █░█ █░▀█ █▀▀ ░▀▄ █░█ █░▄ █░█ █ ░█░
                               █▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀▀ ▀▀░ █▀░ ▀▀▀ ░▀░ ▀ ░▀░   "| lolcat -a -d 50
