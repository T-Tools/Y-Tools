#!PREFIX/etc/bin/bash
#
# Coded by : Ghost Hunter | White Hacker
# More Info : http://www.ypnwhitehacker.blogspot.com
#
#

# START
echo  "      [998898499]   "
clear
echo  "Please Enter Password☺️☺️" | lolcat -a -d 15
read -p "" act;

if [ $act = 9988984992512 ] || [ $act = 9988984992512 ]
then
clear
else
echo "Your Entering Worng Password"| lolcat -a -d 15
echo " You Can Request The Password From Coder" | lolcat -a -d 15
echo " Fb Acc Link Of Coder" | lolcat -a -d 15
echo "https://www.facebook.com/100035201946522" | lolcat -a -d 15
figlet Bye Bye | lolcat -a -d 20
exit
fi
echo ""                                     
echo "                        This Tools Was Made For Easy Way Of Installing Tools" | lolcat -a -d 20
echo "                        All Tools Are Coded By Yell Phone Naing" | lolcat -a -d 20
echo ""
echo "                        ==[ Note:This Tool Is For Beginner " | lolcat -a -d 15
echo "                        ==[ Note:Don't Use This Tool " | lolcat -a -d 15
echo "                        ==[ Note:To Harm Something " | lolcat -a -d 15
echo "                        ==[ Note:Hack Everything,Harm Nothing" | lolcat -a -d 15
echo "                        ==[ Tools Name : Termux Tools" | lolcat -a -d 15
echo "                        ==[ Coded by : Yell Phone Naing" | lolcat -a -d 15
echo "                        ==[ Version : 1.0.0" | lolcat -a -d 15
echo "                        ==[ Program Type :Bash " | lolcat -a -d 15
echo "                        ==[ I Am Myanmer Young Hacker😉😉😉" | lolcat -a -d 20            
echo "                        ==[ www.ypnwhitehacker.blogsplot.com" | lolcat -a -d 15
echo ""
echo "Please Select One To Use" | lolcat -a -d 5
echo ""
echo "  [01] Install MetaSploit" | lolcat -a -d 20
echo "  [02] Install PhoneSploit(ADB)" | lolcat -a -d 20
echo "  [03]Auto Sqlmap Bypass" | lolcat -a -d 20
echo "  [04]IP Tracer" | lolcat -a -d 20
echo "  [05]Termux Logo Changer" | lolcat -a -d 20
echo  "      [0]  Exit " | lolcat -a -d 20
echo  "Choose A Number" | lolcat -a -d 15
read -p "" act;

if [ $act = 1 ] || [ $act = 01 ]
then
clear
pkg install unstable-repo 
pkg install metasploit
echo " To Start Metasploit Type(msfconsole)"
fi

if [ $act = 2 ] || [ $act = 02 ]
then
sh yokffjkhgfiigdusfihy
fi

if [ $act = 3 ] || [ $act = 03 ]
then
clear
bash euhixuzysofudusiuysifoggsud
fi
if [ $act = 4 ] || [ $act = 04 ]
then
clear
pkg install php
php ryjfgjifxuusofxhysfivlxhudogkf
fi
if [ $act = 5 ] || [ $act = 05 ]
then
clear
bash ggjggioogdifxiuxi
fi

if [ $act = 0 ] || [ $act = 0 ]
then
echo "Thank  For Using My Tool☺YPN😊" | lolcat -a -d 15
figlet Bye Bye | lolcat -a -d 15
fi